-- MySQL dump 10.13  Distrib 5.7.12, for Win32 (AMD64)
--
-- Host: localhost    Database: educational_admin_system
-- ------------------------------------------------------
-- Server version	5.7.14-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `course_id` int(9) NOT NULL,
  `course_name` varchar(30) DEFAULT NULL,
  `course_year` int(4) DEFAULT NULL,
  `course_session` int(2) DEFAULT NULL,
  `credit` int(11) DEFAULT NULL,
  `course_hour` int(11) DEFAULT NULL,
  `course_period` varchar(10) DEFAULT NULL,
  `course_type` varchar(25) DEFAULT NULL,
  `course_campus` varchar(10) DEFAULT NULL,
  `course_school` varchar(25) DEFAULT NULL,
  `course_time` varchar(15) DEFAULT NULL,
  `course_room` varchar(5) DEFAULT NULL,
  `course_class_number` int(11) DEFAULT NULL,
  `course_max_stu` int(11) DEFAULT NULL,
  `T_id` int(6) DEFAULT NULL,
  `S_id` int(8) DEFAULT NULL,
  `course_score` int(11) DEFAULT NULL,
  PRIMARY KEY (`course_id`),
  KEY `teacher_id_idx` (`T_id`),
  KEY `student_id_idx` (`S_id`),
  CONSTRAINT `S_id` FOREIGN KEY (`S_id`) REFERENCES `student` (`Stu_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `T_id` FOREIGN KEY (`T_id`) REFERENCES `teacher` (`Teacher_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (201701001,'移动应用开发',2017,1,3,36,'1-18','Public Required','South','SDCS','Mon 8～10','D201',1435314,100,353002,14253003,100),(201701002,'数据库系统',2017,1,3,36,'1-18','Public Elective','Zhuh','SDCS','Tues 2~3','C302',1435302,100,353001,14353004,90),(201701003,'移动Web应用设计',2017,1,3,40,'1-18','Major Required','North','SDCS','Wed 4~5','A101',1435222,100,353002,14353083,80),(201701004,'计算机网络原理',2017,1,3,36,'1-18','Major Elective','Shenz','SDCS','Thur 11~12','D403',1535211,100,353001,15343001,80),(201701005,'人工智能',2017,1,2,40,'1-18','Major Elective','East','SDCS','Fri 8~10','E502',1035209,100,353001,10343002,75);
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-25 14:45:10
